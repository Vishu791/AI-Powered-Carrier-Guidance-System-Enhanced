# CareerGuidanceAI — Enhanced Version
## What Was Added

### 1. ✅ Login Page with OTP
- Email + Password login
- New user registration
- OTP verification (6-digit code printed to console)
- Demo login: `demo@career.ai` / `career123`
- "Login with OTP" option

### 2. ✅ AI Integration (Generative AI)
- New tab: **🤖 AI Advisor Chat**
- Powered by Claude AI (Anthropic API)
- Falls back to smart offline responses if no API key
- Full conversation history maintained

### 3. ✅ Call AI Sites
- Quick links to ChatGPT, Claude AI, Gemini, Perplexity
- Available on Login page AND inside the main app
- Opens in browser with one click

### 4. ✅ All Original Features Preserved
- Career recommendations (ML model + embeddings)
- Roadmap dialogs
- College info dialogs
- Resume PDF builder
- Analytics charts

## How to Run
```
cd ui
python app.py
```

## For Live AI Chat (Optional)
Set your Anthropic API key as environment variable:
```
# Windows:
set ANTHROPIC_API_KEY=your_key_here

# Mac/Linux:
export ANTHROPIC_API_KEY=your_key_here
```
Without the key, the AI chat uses smart offline responses.

## OTP Note
OTP is printed to the console/terminal window. In a production system you would integrate email/SMS delivery.
