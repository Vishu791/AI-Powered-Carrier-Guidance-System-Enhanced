# CareerGuidanceAI — Setup Guide
## New Features Added

### 1. ⚡ OpenAI GPT-4o Mini (Primary AI Chat)
### 2. 🟠 Claude claude-opus-4-5 (Automatic Fallback)
### 3. 📧 Gmail SMTP (Real OTP Emails)

---

## How to Run

```bash
pip install -r requirements.txt
cd ui
python app.py
```

---

## Setting Up API Keys (Inside the App)

After logging in, click the **⚙ API Settings** button in the top bar.

You can enter:
- **OpenAI API Key** — for GPT-4o Mini chat
- **Claude API Key** — used automatically if OpenAI fails
- **Gmail + App Password** — for real OTP emails

### Without keys:
- AI Chat → Uses the built-in offline knowledge base (still works)
- OTP → A popup shows the OTP on screen (demo-friendly)

---

## Getting Your Keys

### OpenAI API Key
1. Go to: https://platform.openai.com/api-keys
2. Click **Create new secret key**
3. Copy it → paste in ⚙ API Settings → OpenAI Key field

### Anthropic Claude Key (optional fallback)
1. Go to: https://console.anthropic.com/
2. Create an API key
3. Copy it → paste in ⚙ API Settings → Claude Key field

### Gmail SMTP — App Password Setup
1. Enable **2-Step Verification** on your Gmail account
2. Go to: https://myaccount.google.com/apppasswords
3. Select App: **Mail** → Device: **Windows Computer**
4. Click **Generate**
5. Copy the **16-character password** (spaces don't matter)
6. In ⚙ API Settings → enter your Gmail + the 16-char App Password
7. Click **🧪 Test SMTP Connection** to verify

> ⚠ Use the App Password, NOT your regular Gmail password.

---

## AI Chat Flow

```
Your message
     ↓
OpenAI GPT-4o Mini  ──✅──▶  Answer shown  [⚡ OpenAI GPT-4o Mini]
     ↓ (if no key or error)
Claude claude-opus-4-5      ──✅──▶  Answer shown  [🟠 Claude Fallback]
     ↓ (if no key or error)
Offline Knowledge Base ──✅──▶  Answer shown  [📚 Offline]
```

The status bar under the chat shows which model responded.

---

## Demo Credentials
- Email: `demo@career.ai`
- Password: `career123`

---

## File Structure
```
CareerGuidanceAI_Enhanced/
├── ui/
│   └── app.py          ← Main app (all features here)
├── model/              ← ML models and career data
├── data/               ← JSON career details
├── requirements.txt
└── README_SETUP.md     ← This file
```
